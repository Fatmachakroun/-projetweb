<?php
  class sms {
	  
    public $LOGIN;
    public $PASSWORD;
    public $SENDER;
    public $DEST;
    public $MESSAGE;


	//Constructeur par paramètres de la classe
    public function __construct($LOGIN, $PASSWORD, $SENDER,$DEST,$MESSAGE ) {
		  $this->LOGIN= $LOGIN;
      $this->PASSWORD   = $PASSWORD;
      $this->SENDER = $SENDER;
	        $this->DEST = $DEST;
      $this->MESSAGE= $MESSAGE;

	  
    }
		public function getElementById()
	{
		return $this->LOGIN;
	}
	public function setLOGIN($LOGIN)
	{
		$this->LOGIN=$LOGIN;
	}
	
		public function getElementByPASSWORD()
	{
		return $this->PASSWORD;
	}
	public function setLOGIN($PASSWORD)
	{
		$this->PASSWORD=$PASSWORD;
	}
	
		public function getElementBySENDER()
	{
		return $this->SENDER;
	}
	public function setSENDER($SENDER)
	{
		$this->SENDER=$SENDER;
	}
	
		public function getElementByDEST()
	{
		return $this->DEST;
	}
	public function setDEST($DEST)
	{
		$this->DEST=$DEST;
	}
		public function getElementByMESSAGE()
	{
		return $this->MESSAGE;
	}
	public function setMESSAGE($MESSAGE)
	{
		$this->MESSAGE=$MESSAGE;
	}
	
	 //Ajout dans la table produit
	 public static function add($LOGIN, $PASSWORD, $SENDER,$DEST,$MESSAGE ) {
       $req="INSERT INTO sms (login, password, sender,dest,message) 
		VALUES ('.$login.','".$password."','".$sender."','".$dest."','".$message."') ";
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
    }
	
	
	
	public static function all() {
      $list = [];
      $db = Db::getInstance();
      $req = $db->query('SELECT * FROM sms');

      // we create a list of Post objects from the database results
       foreach($req->fetchAll() as $sms) {
        $list[] = new sms($sms['login'], $sms['password'],$sms['sender'],$sms['dest'], $sms['message']);
      }
      return $list;
      
    }

	
   
	
	
  }
?>