<?php
  class animaux {
	  
    public $reference;
    public $race;
    public $sexe;
    public $prix;
    public $description;


	//Constructeur par paramètres de la classe
    public function __construct($reference, $race, $sexe,$prix,$description ) {
		  $this->reference  = $reference;
      $this->race      = $race;
      $this->sexe = $sexe;
	        $this->prix = $prix;
      $this->description = $description;

	  
    }
	
	 //Ajout dans la table produit
	 public static function add($reference, $race, $sexe,$prix,$description) {
       $req="INSERT INTO animal (reference, race, sexe,prix,description) 
		VALUES ('.$reference.','".$race."','".$sexe."','.$prix.','".$description."') ";
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
    }
	//supprimer les produits 
	
	
	 public static function delete_($reference,$race) 
	 {
      $req="DELETE FROM animal WHERE reference ='".$reference."' and race ='".$race."'" ;
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
      
    }

		 public static function sum() 
	 {
      
		
         //echo $req;
		 $db = Db::getInstance();
         $req=$db->query("select count(*) FROM animal ");
		return $req->fetch();
    }

		 public static function sum2() 
	 {
      
		
         //echo $req;
		 $db = Db::getInstance();
         $req=$db->query("select count(*) FROM animal where race='chien' ");
		return $req->fetch();
    }
		 public static function sum3() 
	 {
      
		
         //echo $req;
		 $db = Db::getInstance();
         $req=$db->query("select count(*) FROM animal where race='chat' ");
		return $req->fetch();
    }
	 public static function sum4() 
	 {
      
		
         //echo $req;
		 $db = Db::getInstance();
         $req=$db->query("select count(*) FROM animal where race='oiseau' ");
		return $req->fetch();
    }
		 public static function sum5() 
	 {
      
		
         //echo $req;
		 $db = Db::getInstance();
         $req=$db->query("select count(*) FROM animal where race='poisson' ");
		return $req->fetch();
    }


	
    public static function all() {
      $list = [];
      $db = Db::getInstance();
      $req = $db->query('SELECT * FROM animal');

      // we create a list of Post objects from the database results
       foreach($req->fetchAll() as $animaux) {
        $list[] = new animaux($animaux['reference'], $animaux['race'],$animaux['sexe'],$animaux['prix'], $animaux['description']);
      }
      return $list;
      
    }

   public static function find($race) {
      $db = Db::getInstance();
      
      $req = $db->prepare('SELECT * FROM animal WHERE race = :race ');
	  
      // the query was prepared, now we replace reference with our actual $reference value
      $req->execute(array('race' => $race));
												
	foreach($req->fetchAll() as $animaux) {
		
	   $list[]= new animaux($animaux['reference'], $animaux['race'],$animaux['sexe'],$animaux['prix'], $animaux['description']);
	   
	   
      }
	return $list;
  }
  public static function stat($race)
  {
	    $db = Db::getInstance();
         $req=$db->query("select count(*) FROM animal where race='".$race."' ");
		return $req->fetch();
  }

  	public function sendSms()
	{
		

    }
	
	
  }
?>