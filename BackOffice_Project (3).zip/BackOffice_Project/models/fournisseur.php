<?php
  class Fournisseur {
	  
    public $nom;
    public $adresse;
    public $e_mail;
	public $telephone;

	//Constructeur par paramètres de la classe
    public function __construct($nom, $adresse, $e_mail, $telephone ) {
      $this->nom      = $nom;
      $this->adresse  = $adresse;
      $this->e_mail = $e_mail;
	  $this->telephone = $telephone;
    }
	
	 //Ajout dans la table fournisseur
	 public static function add($nom , $adresse , $e_mail, $telephone) {
       $req="INSERT INTO fournisseur(nom,adresse,e_mail,telephone) 
		VALUES (
		'".$nom."',
		'".$adresse."',
		'".$e_mail."',
		" .$telephone.")";
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
    }
	
	 public static function delete_($id) {
      $req="DELETE * FROM fournisseur WHERE identifiant ='".$id."'" ;
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
      
    }

    public static function all() {
      $list = [];
      $db = Db::getInstance();
      $req = $db->query('SELECT * FROM fournisseur');

      // we create a list of Post objects from the database results
      foreach($req->fetchAll() as $post) {
        $list[] = new Post($post['id'], $post['author'], $post['content']);
      }

      return $list;
    }

    public static function find($id) {
      $db = Db::getInstance();
      // we make sure $id is an integer
      $id = intval($id);
      $req = $db->prepare('SELECT * FROM fournisseur WHERE (identifiant = :id OR nom = :id)');
      // the query was prepared, now we replace :id with our actual $id value
      $req->execute(array('id' => $id));
      $post = $req->fetch();

      return new Post($post[''], $post['author'], $post['content']);
    }
	
	
  }
?>