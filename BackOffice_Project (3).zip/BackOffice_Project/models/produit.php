<?php
  class produit {
	  
    public $reference;
    public $nom;
    public $prix;


	//Constructeur par paramètres de la classe
    public function __construct($reference, $nom, $prix ) {
		  $this->reference  = $reference;
      $this->nom      = $nom;
      $this->prix = $prix;
	  
    }
	
	 //Ajout dans la table produit
	 public static function add($reference , $nom , $prix) {
       $req="INSERT INTO produit(reference,nom,prix) 
		VALUES ('.$reference.','".$nom."','.$prix.') ";
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
    }
	//supprimer les produits 
	
	
	 public static function delete_($reference) 
	 {
      $req="DELETE FROM produit WHERE reference ='".$reference."'" ;
		
         echo $req;
		 $db = Db::getInstance();
         $db->query($req);
      
    }
		 public static function sum() 
	 {
      
		
         //echo $req;
		 $db = Db::getInstance();
         $req=$db->query("select count(*) FROM produit ");
		 
		return $req->fetch();
    }

    public static function all() {
      $list = [];
      $db = Db::getInstance();
      $req = $db->query('SELECT * FROM produit');

      // we create a list of Post objects from the database results
      foreach($req->fetchAll() as $produit) {
        $list[] = new produit($produit['reference'], $produit['nom'], $produit['prix']);
      }

      return $list;
    }
	
	

    public static function find($reference) {
      $db = Db::getInstance();
      
      $req = $db->prepare('SELECT * FROM produit WHERE reference = :reference ');
	  
      // the query was prepared, now we replace reference with our actual $reference value
      $req->execute(array('reference' => $reference));
												
	foreach($req->fetchAll() as $produit) {
		
	   $list[]= new produit($produit['reference'], $produit['nom'], $produit['prix']);
	   
	   
      }
		return $list;
  }
  }
  
?>