<?php 

class Administrateur{
	
	private $id;
	private $login;
    private $password;
	private $role;

	public function __construct($id,$login,$pwd,$role)
	{
		$this->id=$id;
		$this->login=$login;
		$this->password=$pwd;
		$this->role=$role;
		
	}
	function getLog()
	{
		return $this->login;
	}
    function getPWD()
	{
		return $this->password;
		
	}
	 function getRole()
	{
		return $this->role;
		
	}

	public static function Logedin($login,$pwd)
	{
		
		 $db = Db::getInstance();
     
      $req = $db->prepare('SELECT * FROM administrateur WHERE login = :login AND password = :pwd');
      // the query was prepared, now we replace :id with our actual $id value
      $req->execute(array('login' => $login,
						  'pwd' => $pwd));
	  
       foreach($req->fetchAll() as $post) {
        $list[] = new Administrateur($post['id'] , $post['login'], $post['password'] , $post['role']);
      }

      return $list ;
	}

	}
	
	

	?>