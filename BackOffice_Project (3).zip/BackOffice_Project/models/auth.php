<?php 


$vide=false;
if (!empty($_POST['login']) && !empty($_POST['pwd'])){
	
	foreach($admin as $t){
		$vide=true;
	if ($t->getLog() ==$_POST['login'] && $t->getPWD() ==$_POST['pwd']){
		
		$_SESSION['login']=$_POST['login'];
		$_SESSION['password']=$_POST['pwd'];
		$_SESSION['r']=$t->getRole();
		
		echo '<meta http-equiv="refresh" content="0;URL=/BackOffice_Project?controller=pages&action=animaux">'; 
		
		}
	
}
if ($vide==false) { 
        
         // puis on le redirige vers la page d'accueil
         echo '<meta http-equiv="refresh" content="0;URL=/BackOffice_Project?controller=admin&action=show">'; 
		 
		  // Le visiteur n'a pas été reconnu comme étant membre de notre site. On utilise alors un petit javascript lui signalant ce fait
         echo '<body onLoad="alert(\'Membre non reconnu...\')">'; 
      } 
}	  
 

?> 
