function verifier()
{
	if (document.from.reference.value=="" )
	{
		alert("le champs de saisie ne doit pas etre vide ");
	}
	
}
