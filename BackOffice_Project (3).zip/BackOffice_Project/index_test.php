<?php

$url = 'https://rest.nexmo.com/sms/json?' . http_build_query(
    [
      'api_key' =>  '194883e8',
      'api_secret' => '1e01b696d243c380',
      'to' => '+21626044783',
      'from' => '+21626044783',
      'text' => 'Bonjour cher client,nous vous informons de nos nouveaux animaux présent en ligne'
    ]
);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,  2);
$response = curl_exec($ch);

echo $response;



?>