<?php
  class PagesController {
    public function home() {
      $first_name = 'Ali';
      $last_name  = 'Harbewi';
      require_once('views/pages/home.php');
    }

    public function error() {
      require_once('views/pages/error.php');
    }
	
	public function fournisseur()
	{
		require_once('views/pages/fournisseur.php');
	}
	public function produit()
	{
		require_once('views/pages/produit.php');
	}
	public function animaux()
	{
		require_once('views/pages/animaux.php');
	}
  }
?>