<?php

  class smsController {
    public function addForm() {
      //On recupere les entrées du formulaire pour ajout dans la bases de données
      sms::add($sms['login'], $sms['password'],$sms['sender'],$sms['dest'], $sms['message']);
	  
	  
      require_once('views/pages/animaux.php');
    }

    public function display() {
		
      //if (!isset($_GET['list']))
      //  return call('pages', 'error');

      // we use the given reference to get the right post
      $sms = sms::all();
	   
      require_once('views/posts/index.php');
    }
	
	
  }
?>