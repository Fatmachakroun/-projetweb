<?php
  class AdministrateursController {
    
	
	public function show() {
		
		require_once('views/pages/authentification.php') ;
	}
	
	public function signIn() {
     
	   $admin = Administrateur::Logedin($_POST['login'],$_POST['pwd']) ;
	   require_once("models/auth.php") ;
    }
	
	public function signOut(){
	
		// On détruit les variables de notre session
		session_unset ();

		// On détruit notre session
		session_destroy ();

		// On redirige le visiteur vers la page d'accueil
		echo '<meta http-equiv="refresh" content="0;URL=/BackOffice_Project?controller=admin&action=show">'; 
	}
  }
?>