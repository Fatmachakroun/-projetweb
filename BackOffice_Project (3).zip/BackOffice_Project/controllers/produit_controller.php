<?php
  class produitController {
    public function addForm() {
      //On recupere les entrées du formulaire pour ajout dans la bases de données
      produit::add($_POST['reference'] , $_POST['nom'] , $_POST['prix'] );
	  
	  
      require_once('views/pages/produit.php');
    }

    public function display() {
		
     // if (!isset($_GET['list']))
      //  return call('pages', 'error');
  $produit = produit::all();
	   
      require_once('views/posts/index1.php');
    }
	
	
	public function deleteForm() {
          
      produit::delete_($_POST['reference']);
      require_once('views/pages/produit.php');
    }
		public function sum() {
          
      $produit=produit::sum();
	 
      require_once('views/pages/produit.php');
    }
	
	
	public function find() {
     $produit= [];     
      $produit=produit::find ($_POST['reference']);
	 
      require_once('views/posts/index2.php');
    }
  }
?>