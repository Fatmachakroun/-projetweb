<?php
  class FournisseursController {
    public function addForm() {
      //On recupere les entrées du formulaire pour ajout dans la bases de données
      Fournisseur::add($_POST['nom'] , $_POST['adresse'] , $_POST['e_mail'] , $_POST['telephone']);
	  
	  
      require_once('views/pages/fournisseur.php');
    }

    public function display() {
		
      if (!isset($_GET['id']))
        return call('pages', 'error');

      // we use the given id to get the right post
      $post = Post::find($_GET['id']);
      require_once('views/posts/show.php');
    }
	
	public function deleteForm() {
          
      Fournisseur::delete_($_POST['identifiant']);
      require_once('views/pages/fournisseur.php');
    }
  }
?>