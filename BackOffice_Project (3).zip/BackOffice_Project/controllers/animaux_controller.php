<?php

  class animauxController {
    public function addForm() {
      //On recupere les entrées du formulaire pour ajout dans la bases de données
      animaux::add($_POST['reference'] , $_POST['race'] ,$_POST['sexe'],$_POST['prix'] ,$_POST['description']);
	  
	   
      require_once('views/pages/animaux.php');
    }
	
	
    public function display() {
		
      //if (!isset($_GET['list']))
      //  return call('pages', 'error');

      // we use the given reference to get the right post
      $animaux = animaux::all();
	  
	   
      //require_once('views/pages/animaux.php');
      require_once('views/posts/index.php');
	  
    }
	
	
	
	
	public function deleteForm() {
          
      animaux::delete_($_POST['reference'],$_POST['race']);
      require_once('views/pages/animaux.php');
    }
	
	public function sum() {
          
      $animaux=animaux::sum();
      require_once('views/pages/animaux.php');
    }
	
	public function sum2() {
          
      $animaux=animaux::sum2();
      require_once('views/pages/animaux.php');
    }
	public function sum3() {
          
      $animaux=animaux::sum3();
      require_once('views/pages/animaux.php');
    }
	public function stat() {
          
      $animaux=animaux::stat('chien');
      require_once('views/pages/animaux.php');
	  
    }
	
	public function sum5() {
          
      $animaux=animaux::sum5();
      require_once('views/pages/animaux.php');
    }

	
	public function find() {
     $animaux= [];     
      $animaux=animaux::find ($_POST['race']);
	 
      require_once('views/posts/chercher.php');
    }
	public function sendSms(){
        $key_nexmo='194883e8';
        $secret_nexmo='1e01b696d243c380';
        $url = 'https://rest.nexmo.com/sms/json?' . http_build_query(
                [
                    'api_key' =>  $key_nexmo,
                    'api_secret' => $secret_nexmo,
                    'to' => 26044783,
                    'from' => '441632960061',
                    'text' => ' Nouveau produit dans notre shop .'
                ]
            );

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);

        echo $response;

    }
  }
?>