<?php require_once("models/animaux.php"); ?><div id='myChart'><a class="zc-ref" href="https://www.zingchart.com/">Charts by ZingChart</a></div></center>
<?php 
$chien=animaux::stat('chien');
var_dump($chien);
$chat=animaux::stat('chat');
$oiseau=animaux::stat('oiseau');
?>
<script>
    var myConfig = {
      type: "pie",
      backgroundColor: "#2B313B",
      plot: {
        borderColor: "#2B313B",
        borderWidth: 5,
        // slice: 90,
        valueBox: {
          placement: 'out',
          text: '%t\n%npv%',
          fontFamily: "Open Sans"
        },
        tooltip: {
          fontSize: '18',
          fontFamily: "Open Sans",
          padding: "5 10",
          text: "%npv%"
        },
        animation: {
          effect: 2,
          method: 5,
          speed: 500,
          sequence: 1
        }
      },
      source: {
        text: '',
        fontColor: "#8e99a9",
        fontFamily: "Open Sans"
      },
      title: {
        fontColor: "#fff",
        text: 'Statistique Commande',
        align: "left",
        offsetX: 10,
        fontFamily: "Open Sans",
        fontSize: 25
      },
      subtitle: {
        offsetX: 10,
        offsetY: 10,
        fontColor: "#8e99a9",
        fontFamily: "Open Sans",
        fontSize: "16",
        text: 'Année 2017',
        align: "left"
      },
      plotarea: {
        margin: "20 0 0 0"
      },
      series: [{
        values: [<?php echo intval($chien[0]);?>],
        text: "Chien",
        backgroundColor: '#50ADF5',
      }, {
        values: [<?php echo intval($chat[0]);?>],
        text: "Chat",
        backgroundColor: '#FF7965'
      }, {
        values: [<?php echo intval($oiseau[0]);?>],
        text: 'Oiseau',
        backgroundColor: '#FFCB45'
      }]
    };

    zingchart.render({
      id: 'myChart',
      data: myConfig,
      height: 500,
      width: 725
    });
  </script>

</div>