

<?php
// this line loads the library
require('/path/to/twilio-php/Services/Twilio.php');
$account_sid = 'AC3ca93009fb3ce2d09c619d5c88a9039e';
$auth_token = 'a7ccc8e4ddd149d993a120a226046e12';
$client = new Services_Twilio($account_sid, $auth_token);
$client->account->messages->create(array(
  'To' => "+21695378495",
  'From' => "+13528355190",
  'Body' => "Tomorrow's forecast in Financial District, San Francisco is Clear.",
  'MediaUrl' => "https://climacons.herokuapp.com/clear.png", 
));

?>