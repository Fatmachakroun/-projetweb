alert("boobo");
function verifier()
{
	
	with(document.form)
	{
		if(race.value=="")
		{
			alert("le champs de saisie ne doit pas etre vide ");
			return false;
		}
}
