<div class="span8">
<center><div id='myChart'><a class="zc-ref" href="https://www.zingchart.com/">Charts by ZingChart</a></div></center>
<?php 
$ja=Commande::stat(1);

$fe=Commande::stat(2);
$mar=Commande::stat(3);
$av=Commande::stat(4);
//var_dump($av);
$mai=Commande::stat(5);
//var_dump($mai[0]);
$juin=Commande::stat(6);
$juil=Commande::stat(7);
$aou=Commande::stat(8);
$sep=Commande::stat(9);
$oct=Commande::stat(10);
$nov=Commande::stat(11);
$dec=Commande::stat(12);
?>
<script>
    var myConfig = {
      type: "pie",
      backgroundColor: "#2B313B",
      plot: {
        borderColor: "#2B313B",
        borderWidth: 5,
        // slice: 90,
        valueBox: {
          placement: 'out',
          text: '%t\n%npv%',
          fontFamily: "Open Sans"
        },
        tooltip: {
          fontSize: '18',
          fontFamily: "Open Sans",
          padding: "5 10",
          text: "%npv%"
        },
        animation: {
          effect: 2,
          method: 5,
          speed: 500,
          sequence: 1
        }
      },
      source: {
        text: '',
        fontColor: "#8e99a9",
        fontFamily: "Open Sans"
      },
      title: {
        fontColor: "#fff",
        text: 'Statistique Commande',
        align: "left",
        offsetX: 10,
        fontFamily: "Open Sans",
        fontSize: 25
      },
      subtitle: {
        offsetX: 10,
        offsetY: 10,
        fontColor: "#8e99a9",
        fontFamily: "Open Sans",
        fontSize: "16",
        text: 'Année 2017',
        align: "left"
      },
      plotarea: {
        margin: "20 0 0 0"
      },
      series: [{
        values: [<?php echo intval($ja[0]);?>],
        text: "Janvier",
        backgroundColor: '#50ADF5',
      }, {
        values: [<?php echo intval($fe[0]);?>],
        text: "Fevrier",
        backgroundColor: '#FF7965'
      }, {
        values: [<?php echo intval($mar[0]);?>],
        text: 'Mars',
        backgroundColor: '#FFCB45'
      }, {
        text: 'Avril',
        values: [<?php echo intval($av[0]);?>],
        backgroundColor: '#6877e5'
      }, {
        text: 'Mai',
        values: [<?php echo intval($mai[0]);?>],
        backgroundColor: '#6FB07F'
      },{
        text: 'Juin',
        values: [<?php echo intval($juin[0]);?>],
        backgroundColor: '#FF7965'
      },{
        text: 'Juillet',
        values: [<?php echo intval($juil[0]);?>],
        backgroundColor: '#6877e5'
      },{
        text: 'Aout',
        values: [<?php echo intval($aou[0]);?>],
        backgroundColor: '#FFCB45'
      },{
        text: 'Septembre',
        values: [<?php echo intval($sep[0]);?>],
        backgroundColor: '#fff'
      },{
        text: 'Octobre',
        values: [<?php echo intval($oct[0]);?>],
        backgroundColor: '#6FB07F'
      },{
        text: 'Novembre',
        values: [<?php echo intval($nov[0]);?>],
        backgroundColor: '#8e99a9'
      },{
        text: 'Decembre',
        values: [<?php echo intval($dec[0]);?>],
        backgroundColor: '#6FB07F'
      }]
    };

    zingchart.render({
      id: 'myChart',
      data: myConfig,
      height: 500,
      width: 725
    });
  </script>

</div>
</div>