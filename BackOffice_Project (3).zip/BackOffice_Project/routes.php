<?php
  function call($controller, $action) {
    require_once('controllers/' . $controller . '_controller.php');

    switch($controller) {
      case 'pages':
        $controller = new PagesController();
      break;
      case 'posts':
        // we need the model to query the database later in the controller
        require_once('models/post.php');
        $controller = new PostsController();
      break;
	  case 'fournisseurs':
        require_once('models/fournisseur.php');
        $controller = new FournisseursController();
      break;
	   case 'produit':
        require_once('models/produit.php');
        $controller = new produitController();
		
      break;
	   case 'animaux':
        require_once('models/animaux.php');
        $controller = new animauxController();
      break;
	   case 'admin':
        require_once('models/administrateur.php');
        $controller = new AdministrateursController();
      break;
      case 'sms':
        require_once('models/sms.php');
        $controller = new smsController();
      break;
    }

    $controller->{ $action }();
  }

  // we're adding an entry for the new controller and its actions
  $controllers = array('pages' => ['home', 'error' , 'fournisseur','produit','animaux','sms'],
                       'posts' => ['index', 'show'],
					   'fournisseurs' => ['addForm', 'display', 'deleteForm'],
					   'produit' => ['addForm', 'display', 'deleteForm','find','sum'],
					   'animaux' => ['addForm', 'display', 'deleteForm','find','sum','sum2','sum3','stat'],
					   'admin' => ['show' , 'signIn', 'signOut'],
					   'sms' => ['addForm' , 'display']);


  if (array_key_exists($controller, $controllers)) {
    if (in_array($action, $controllers[$controller])) {
      call($controller, $action);
    } else {
      call('pages', 'error');
    }
  } else {
    call('pages', 'error');
  }
?>